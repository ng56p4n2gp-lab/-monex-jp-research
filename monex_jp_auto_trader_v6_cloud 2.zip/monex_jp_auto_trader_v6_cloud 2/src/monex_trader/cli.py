import argparse,pandas as pd
from .jpx_universe import build_latest_universe
from .free_data import download_intraday,merge_history
from .backtest import run_backtest
from .strict100 import strict_historical_100_candidates

def main():
    p=argparse.ArgumentParser()
    s=p.add_subparsers(dest="cmd",required=True)

    u=s.add_parser("universe")
    u.add_argument("--out",default="data/master/tse_symbols.csv")
    u.add_argument("--xlsx",default=None)

    d=s.add_parser("download-free")
    d.add_argument("--symbols",required=True)
    d.add_argument("--interval",default="5m")
    d.add_argument("--period",default="60d")
    d.add_argument("--out",default="data/cache/history_5m.csv")
    d.add_argument("--report",default="data/cache/download_report.csv")
    d.add_argument("--start-row",type=int,default=0)
    d.add_argument("--limit",type=int,default=0)

    b=s.add_parser("backtest")
    b.add_argument("--bars",required=True)
    b.add_argument("--shares",type=int,default=100)
    b.add_argument("--target",type=float,default=1000)
    b.add_argument("--slippage",type=float,default=1.0)
    b.add_argument("--results",default="results.csv")
    b.add_argument("--candidates",default="strict100_candidates.csv")

    a=p.parse_args()
    if a.cmd=="universe":
        x=build_latest_universe(a.out,a.xlsx)
        print(f"saved {len(x)} symbols -> {a.out}")
    elif a.cmd=="download-free":
        m=pd.read_csv(a.symbols)
        codes=m["code"].astype(str).tolist()[a.start_row:]
        if a.limit>0: codes=codes[:a.limit]
        new,rep=download_intraday(codes,a.interval,a.period,report_path=a.report)
        x=merge_history(new,a.out)
        print(f"history rows={len(x)}")
        print(f"download ok={(rep.status=='ok').sum()} missing={(rep.status!='ok').sum()}")
    elif a.cmd=="backtest":
        bars=pd.read_csv(a.bars)
        bars["timestamp"]=pd.to_datetime(bars["timestamp"])
        r=run_backtest(bars,a.shares,a.target,slippage_yen=a.slippage)
        r.to_csv(a.results,index=False)
        c,folds=strict_historical_100_candidates(r)
        c.to_csv(a.candidates,index=False)
        print("walk-forward folds:",folds)
        print(f"candidates={len(c)}")
        print("NO STRICT 100% PATTERN -> TRADE NOTHING" if c.empty else c.head(30).to_string(index=False))

if __name__=="__main__":
    main()
