from __future__ import annotations
from pathlib import Path
import time
import pandas as pd
import yfinance as yf

COLS=["timestamp","symbol","open","high","low","close","volume"]

def yahoo_symbol(code: str) -> str:
    s=str(code).strip()
    return s if s.endswith(".T") else f"{s}.T"

def _normalize(df,sym):
    if df is None or len(df)==0:
        return pd.DataFrame(columns=COLS)
    x=df.reset_index()
    dtcol=x.columns[0]
    x=x.rename(columns={dtcol:"timestamp","Open":"open","High":"high","Low":"low","Close":"close","Volume":"volume"})
    x["symbol"]=sym.replace(".T","")
    if any(c not in x.columns for c in COLS):
        return pd.DataFrame(columns=COLS)
    x=x[COLS]
    x["timestamp"]=pd.to_datetime(x["timestamp"],errors="coerce")
    for c in ["open","high","low","close","volume"]:
        x[c]=pd.to_numeric(x[c],errors="coerce")
    return x.dropna(subset=["timestamp","open","high","low","close"])

def download_intraday(symbols, interval="5m", period="60d", batch_size=20,
                      pause=2.0, retries=3, report_path=None):
    frames=[]
    report=[]
    syms=[yahoo_symbol(s) for s in symbols]
    for i in range(0,len(syms),batch_size):
        batch=syms[i:i+batch_size]
        raw=None
        err=""
        for attempt in range(1,retries+1):
            try:
                raw=yf.download(
                    tickers=" ".join(batch), period=period, interval=interval,
                    group_by="ticker", auto_adjust=False, actions=False,
                    threads=False, progress=False, prepost=False, timeout=30
                )
                if raw is not None and len(raw)>0:
                    break
            except Exception as e:
                err=str(e)
            time.sleep(pause*attempt)

        for sym in batch:
            f=pd.DataFrame(columns=COLS)
            try:
                if raw is not None and len(raw)>0:
                    if len(batch)==1:
                        f=_normalize(raw,sym)
                    elif hasattr(raw.columns,"levels") and sym in raw.columns.get_level_values(0):
                        f=_normalize(raw[sym],sym)
            except Exception as e:
                err=str(e)

            if not f.empty:
                frames.append(f)
                report.append({
                    "symbol":sym.replace(".T",""),"status":"ok","rows":len(f),
                    "first_timestamp":f["timestamp"].min(),
                    "last_timestamp":f["timestamp"].max(),"error":""
                })
            else:
                report.append({
                    "symbol":sym.replace(".T",""),"status":"missing","rows":0,
                    "first_timestamp":"","last_timestamp":"","error":err
                })
        time.sleep(pause)

    rep=pd.DataFrame(report)
    if report_path:
        Path(report_path).parent.mkdir(parents=True,exist_ok=True)
        rep.to_csv(report_path,index=False)

    if not frames:
        return pd.DataFrame(columns=COLS),rep
    out=(pd.concat(frames,ignore_index=True)
           .sort_values(["symbol","timestamp"])
           .drop_duplicates(["symbol","timestamp"],keep="last"))
    return out,rep

def merge_history(new_df: pd.DataFrame,path):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():
        old=pd.read_csv(p)
        old["timestamp"]=pd.to_datetime(old["timestamp"],errors="coerce")
        out=pd.concat([old,new_df],ignore_index=True)
    else:
        out=new_df.copy()
    out=(out.drop_duplicates(["symbol","timestamp"],keep="last")
            .sort_values(["symbol","timestamp"]))
    out.to_csv(p,index=False)
    return out
