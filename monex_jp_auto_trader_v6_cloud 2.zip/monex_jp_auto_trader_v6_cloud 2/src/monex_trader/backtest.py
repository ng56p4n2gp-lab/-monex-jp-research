import pandas as pd
from .fees import net_profit_after_costs
from .features import add_features

FEATURES=["ret_1","ret_2","ret_3","volume_ratio","vwap_gap","breakout12","range_pct","minute_of_day","weekday"]

def _session_id(ts):
    t=pd.Timestamp(ts)
    m=t.hour*60+t.minute
    # Current TSE cash sessions: 09:00-11:30 and 12:30-15:30 JST.
    if 540 <= m <= 690: return f"{t.date()}-AM"
    if 750 <= m <= 930: return f"{t.date()}-PM"
    return None

def run_backtest(df,shares=100,target=1000,tax_rate=0.20315,windows=(5,10),
                 slippage_yen=1.0):
    x=add_features(df)
    x["session_id"]=x["timestamp"].map(_session_id)
    x=x[x["session_id"].notna()].copy()
    out=[]
    for symbol,g in x.groupby("symbol"):
        g=g.sort_values("timestamp").reset_index(drop=True)
        times=pd.to_datetime(g["timestamp"])
        for i in range(len(g)-1):
            entry_t=times.iloc[i]
            sid=g.iloc[i]["session_id"]
            entry_p=float(g.iloc[i]["close"])+slippage_yen
            for w in windows:
                fut=g[(times>entry_t)&(times<=entry_t+pd.Timedelta(minutes=w))&(g["session_id"]==sid)]
                if fut.empty: continue
                best=float("-inf"); worst=float("inf"); hit=None
                # Conservative approximation: sell realization price is bar high minus slippage.
                for _,r in fut.iterrows():
                    sell_hi=max(0,float(r["high"])-slippage_yen)
                    sell_lo=max(0,float(r["low"])-slippage_yen)
                    hi=net_profit_after_costs(entry_p,sell_hi,shares,tax_rate).net_profit
                    lo=net_profit_after_costs(entry_p,sell_lo,shares,tax_rate).net_profit
                    best=max(best,hi); worst=min(worst,lo)
                    if hit is None and hi>=target:
                        hit=r["timestamp"]
                last=fut.iloc[-1]
                end_sell=max(0,float(last["close"])-slippage_yen)
                end=net_profit_after_costs(entry_p,end_sell,shares,tax_rate).net_profit
                row={"symbol":symbol,"entry_time":entry_t,"entry_price":entry_p,
                     "window_min":w,"target_hit":hit is not None,
                     "target_hit_time":hit,"best_net_profit":best,
                     "worst_net_profit":worst,"end_net_profit":end}
                for f in FEATURES: row[f]=g.iloc[i].get(f)
                out.append(row)
    return pd.DataFrame(out)
