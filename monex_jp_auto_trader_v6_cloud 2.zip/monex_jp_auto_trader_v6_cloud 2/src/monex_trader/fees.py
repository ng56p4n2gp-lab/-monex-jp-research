from dataclasses import dataclass

@dataclass(frozen=True)
class FeeResult:
    buy_fee: int
    sell_fee: int
    tax: float
    net_profit: float

def monex_spot_fee(order_value_yen: float) -> int:
    v = float(order_value_yen)
    if v <= 50_000: return 55
    if v <= 100_000: return 99
    if v <= 200_000: return 115
    if v <= 500_000: return 275
    if v <= 1_000_000: return 535
    if v <= 1_500_000: return 640
    if v <= 30_000_000: return 1013
    return 1070

def net_profit_after_costs(buy_price, sell_price, shares, tax_rate=0.20315):
    buy_value = float(buy_price) * int(shares)
    sell_value = float(sell_price) * int(shares)
    buy_fee = monex_spot_fee(buy_value)
    sell_fee = monex_spot_fee(sell_value)
    gross_after_fees = sell_value - buy_value - buy_fee - sell_fee
    tax = max(0.0, gross_after_fees) * tax_rate
    return FeeResult(buy_fee, sell_fee, tax, gross_after_fees - tax)
