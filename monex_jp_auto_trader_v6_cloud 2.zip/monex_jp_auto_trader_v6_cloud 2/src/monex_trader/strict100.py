import pandas as pd

GROUP=["window_min","breakout12","volume_bucket","vwap_bucket","range_bucket","time_bucket","weekday"]

def _fixed_buckets(x):
    z=x.copy()
    z["volume_bucket"]=pd.cut(z["volume_ratio"],[-1,1,1.5,2,3,5,10,float("inf")])
    z["vwap_bucket"]=pd.cut(z["vwap_gap"],[-float("inf"),-0.02,-0.01,-0.005,0,0.005,0.01,0.02,float("inf")])
    z["range_bucket"]=pd.cut(z["range_pct"],[-1,0.0025,0.005,0.01,0.02,0.04,float("inf")])
    z["time_bucket"]=pd.cut(z["minute_of_day"],[0,555,570,600,660,690,750,810,870,930,1440],include_lowest=True)
    return z

def _summary(d,prefix):
    q=(d.groupby(GROUP,observed=True)
       .agg(samples=("target_hit","size"),hit_rate=("target_hit","mean"),
            avg_best=("best_net_profit","mean"),avg_worst=("worst_net_profit","mean"),
            avg_end=("end_net_profit","mean")).reset_index())
    return q.rename(columns={c:f"{prefix}_{c}" for c in ["samples","hit_rate","avg_best","avg_worst","avg_end"]})

def strict_historical_100_candidates(results,min_train=50,min_valid=15,max_avg_adverse=1200,folds=3):
    x=_fixed_buckets(results).sort_values("entry_time")
    dates=sorted(pd.to_datetime(x["entry_time"]).dt.date.unique())
    if len(dates)<20:
        return pd.DataFrame(), []

    # Expanding-window walk-forward. A pattern must survive every validation fold in which it appears.
    cut_points=[]
    base=max(10,int(len(dates)*0.55))
    remaining=len(dates)-base
    fold_size=max(3,remaining//folds)
    merged=None
    used=[]
    for k in range(folds):
        train_end=base+k*fold_size
        valid_end=len(dates) if k==folds-1 else min(len(dates),train_end+fold_size)
        if valid_end<=train_end: continue
        train_dates=set(dates[:train_end])
        valid_dates=set(dates[train_end:valid_end])
        tr=x[pd.to_datetime(x["entry_time"]).dt.date.isin(train_dates)]
        va=x[pd.to_datetime(x["entry_time"]).dt.date.isin(valid_dates)]
        a=_summary(tr,f"f{k}_train")
        b=_summary(va,f"f{k}_valid")
        m=a.merge(b,on=GROUP,how="inner")
        m=m[(m[f"f{k}_train_samples"]>=min_train)&
            (m[f"f{k}_valid_samples"]>=min_valid)&
            (m[f"f{k}_train_hit_rate"]==1.0)&
            (m[f"f{k}_valid_hit_rate"]==1.0)&
            (m[f"f{k}_valid_avg_worst"]>=-abs(max_avg_adverse))]
        merged=m if merged is None else merged.merge(m,on=GROUP,how="inner")
        used.append((min(train_dates),max(train_dates),min(valid_dates),max(valid_dates)))

    if merged is None or merged.empty:
        return pd.DataFrame(),used
    valid_sample_cols=[c for c in merged.columns if c.endswith("_valid_samples")]
    merged["validation_samples_total"]=merged[valid_sample_cols].sum(axis=1)
    return merged.sort_values("validation_samples_total",ascending=False),used
