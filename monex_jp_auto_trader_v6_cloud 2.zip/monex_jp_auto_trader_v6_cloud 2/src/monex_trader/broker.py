class MonexBroker:
    def __init__(self, live_trading=False):
        self.live_trading=bool(live_trading)
    def buy(self,*args,**kwargs):
        raise RuntimeError("LIVE TRADING LOCKED: official Monex order route not configured.")
    def sell(self,*args,**kwargs):
        raise RuntimeError("LIVE TRADING LOCKED: official Monex order route not configured.")
