import pandas as pd
import numpy as np

def add_features(df):
    x = df.sort_values(["symbol","timestamp"]).copy()
    g = x.groupby("symbol", group_keys=False)
    x["ret_1"] = g["close"].pct_change()
    x["ret_2"] = g["close"].pct_change(2)
    x["ret_3"] = g["close"].pct_change(3)
    x["vol_ma12"] = g["volume"].transform(lambda s: s.rolling(12, min_periods=5).mean())
    x["volume_ratio"] = x["volume"] / x["vol_ma12"].replace(0, np.nan)

    d = pd.to_datetime(x["timestamp"])
    session = d.dt.date
    typ = (x["high"]+x["low"]+x["close"])/3
    pv = typ*x["volume"]
    x["vwap"] = pv.groupby([x["symbol"], session]).cumsum() / x["volume"].groupby([x["symbol"], session]).cumsum().replace(0, np.nan)
    x["vwap_gap"] = x["close"]/x["vwap"] - 1
    x["prev_high12"] = g["high"].transform(lambda s:s.shift(1).rolling(12,min_periods=5).max())
    x["breakout12"] = (x["close"] > x["prev_high12"]).astype(int)
    x["range_pct"] = (x["high"]-x["low"])/x["close"].replace(0,np.nan)
    x["minute_of_day"] = d.dt.hour*60+d.dt.minute
    x["weekday"] = d.dt.weekday
    return x
