from __future__ import annotations
from io import BytesIO
from urllib.parse import urljoin
import re
import requests
import pandas as pd
from bs4 import BeautifulSoup

JPX_LIST_PAGE = "https://www.jpx.co.jp/markets/statistics-equities/misc/01.html"

def _find_col(cols, words):
    for c in cols:
        s = str(c).strip().lower()
        if all(w.lower() in s for w in words):
            return c
    for c in cols:
        s = str(c).strip().lower()
        if any(w.lower() in s for w in words):
            return c
    return None

def discover_latest_jpx_excel(session=None) -> str:
    s = session or requests.Session()
    r = s.get(JPX_LIST_PAGE, timeout=30, headers={"User-Agent":"Mozilla/5.0"})
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")

    links = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if re.search(r"\.(xlsx?|xls)(?:$|\?)", href, re.I):
            links.append(urljoin(JPX_LIST_PAGE, href))

    # JPX page can change. Prefer files whose URL/name suggests listed issues.
    preferred = [u for u in links if any(k in u.lower() for k in ["data_j", "list", "stock", "misc"])]
    candidates = preferred or links
    if not candidates:
        raise RuntimeError(
            "JPX Excel link could not be found automatically. "
            "Download the latest '東証上場銘柄一覧' Excel from the official JPX page and use --xlsx."
        )
    return candidates[0]

def read_jpx_excel_from_url(url: str, session=None) -> pd.DataFrame:
    s = session or requests.Session()
    r = s.get(url, timeout=60, headers={"User-Agent":"Mozilla/5.0"})
    r.raise_for_status()
    return pd.read_excel(BytesIO(r.content))

def build_universe_from_frame(df: pd.DataFrame) -> pd.DataFrame:
    code_col = _find_col(df.columns, ["コード"]) or _find_col(df.columns, ["code"])
    name_col = _find_col(df.columns, ["銘柄名"]) or _find_col(df.columns, ["name"])
    market_col = _find_col(df.columns, ["市場"]) or _find_col(df.columns, ["market"])
    product_col = _find_col(df.columns, ["商品"]) or _find_col(df.columns, ["product"])

    if code_col is None:
        raise ValueError(f"Could not find issue code column. columns={list(df.columns)}")

    x = pd.DataFrame()
    x["code"] = df[code_col].astype(str).str.extract(r"([0-9A-Z]{4,5})", expand=False)
    x["name"] = df[name_col].astype(str) if name_col is not None else ""
    x["market"] = df[market_col].astype(str) if market_col is not None else ""
    x["product"] = df[product_col].astype(str) if product_col is not None else ""

    # Prime/Standard/Growth only when market info exists.
    if market_col is not None:
        x = x[x["market"].str.contains("プライム|スタンダード|グロース|Prime|Standard|Growth", case=False, regex=True, na=False)]

    # Remove non-common-stock products when product info exists.
    if product_col is not None:
        bad = r"ETF|ETN|REIT|投資法人|受益証券|出資証券|優先|インフラ"
        x = x[~x["product"].str.contains(bad, case=False, regex=True, na=False)]

    # Yahoo Japan ticker convention currently works best with ordinary 4-digit numeric codes.
    x = x[x["code"].str.fullmatch(r"\d{4}", na=False)]
    x = x.drop_duplicates("code").sort_values("code").reset_index(drop=True)
    return x

def build_latest_universe(out_path: str, xlsx_path: str | None = None) -> pd.DataFrame:
    if xlsx_path:
        df = pd.read_excel(xlsx_path)
    else:
        url = discover_latest_jpx_excel()
        df = read_jpx_excel_from_url(url)
    uni = build_universe_from_frame(df)
    uni.to_csv(out_path, index=False)
    return uni
