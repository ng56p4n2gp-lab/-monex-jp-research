from __future__ import annotations
from pathlib import Path
import argparse
import json
import math
import time
import pandas as pd

from monex_trader.jpx_universe import build_latest_universe
from monex_trader.free_data import download_intraday
from monex_trader.backtest import run_backtest
from monex_trader.strict100 import strict_historical_100_candidates

def ensure_dirs():
    for p in ["data/master","data/cache","outputs"]:
        Path(p).mkdir(parents=True, exist_ok=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--interval", default="5m")
    ap.add_argument("--period", default="60d")
    ap.add_argument("--batch-size", type=int, default=20)
    ap.add_argument("--symbol-chunk", type=int, default=100)
    ap.add_argument("--shares", type=int, default=100)
    ap.add_argument("--target", type=float, default=1000)
    ap.add_argument("--slippage", type=float, default=1.0)
    args = ap.parse_args()

    ensure_dirs()

    # 1) Official JPX current universe
    universe_path = Path("data/master/tse_symbols.csv")
    uni = build_latest_universe(str(universe_path))
    codes = uni["code"].astype(str).tolist()

    print(f"JPX universe: {len(codes)} symbols")

    # 2) Download in chunks, persist parquet incrementally.
    all_reports = []
    part_files = []
    for n, start in enumerate(range(0, len(codes), args.symbol_chunk), start=1):
        chunk = codes[start:start+args.symbol_chunk]
        print(f"[download chunk {n}] symbols {start}..{start+len(chunk)-1}")
        bars, rep = download_intraday(
            chunk,
            interval=args.interval,
            period=args.period,
            batch_size=args.batch_size,
            pause=2.0,
            retries=3,
            report_path=None
        )
        rep["chunk"] = n
        all_reports.append(rep)

        if not bars.empty:
            part = Path(f"data/cache/bars_part_{n:03d}.parquet")
            bars.to_parquet(part, index=False, compression="zstd")
            part_files.append(part)
        time.sleep(2)

    report = pd.concat(all_reports, ignore_index=True) if all_reports else pd.DataFrame()
    report.to_csv("outputs/download_report.csv", index=False)

    ok_symbols = int((report.get("status") == "ok").sum()) if not report.empty else 0
    missing_symbols = int((report.get("status") != "ok").sum()) if not report.empty else len(codes)

    # 3) Backtest each downloaded part to control memory.
    result_parts = []
    total_rows = 0
    for idx, part in enumerate(part_files, start=1):
        bars = pd.read_parquet(part)
        total_rows += len(bars)
        print(f"[backtest {idx}/{len(part_files)}] {part.name}: {len(bars)} bars")
        r = run_backtest(
            bars,
            shares=args.shares,
            target=args.target,
            slippage_yen=args.slippage
        )
        if not r.empty:
            rp = Path(f"data/cache/results_part_{idx:03d}.parquet")
            r.to_parquet(rp, index=False, compression="zstd")
            result_parts.append(rp)

    # 4) Combine only result rows, then strict walk-forward validation.
    if result_parts:
        results = pd.concat([pd.read_parquet(p) for p in result_parts], ignore_index=True)
        results.to_parquet("outputs/backtest_results.parquet", index=False, compression="zstd")
        candidates, folds = strict_historical_100_candidates(results)
    else:
        results = pd.DataFrame()
        candidates = pd.DataFrame()
        folds = []

    candidates.to_csv("outputs/strict100_candidates.csv", index=False)

    # 5) Produce compact summary for iPhone.
    summary = {
        "requested_period": args.period,
        "interval": args.interval,
        "universe_symbols": len(codes),
        "download_ok_symbols": ok_symbols,
        "download_missing_symbols": missing_symbols,
        "downloaded_bar_rows": int(total_rows),
        "backtest_rows": int(len(results)),
        "strict100_candidate_count": int(len(candidates)),
        "target_net_profit_yen": args.target,
        "shares": args.shares,
        "slippage_yen_each_side_assumption": args.slippage,
        "walk_forward_folds": [
            {
                "train_start": str(x[0]), "train_end": str(x[1]),
                "validation_start": str(x[2]), "validation_end": str(x[3])
            } for x in folds
        ],
        "future_100_percent_guaranteed": False,
        "live_trading_enabled": False,
        "decision": "NO_TRADE" if candidates.empty else "HISTORICAL_CANDIDATES_FOUND"
    }
    Path("outputs/summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # Human-readable result
    lines = [
        "# 60日学習結果",
        f"- 東証対象銘柄数: {len(codes)}",
        f"- データ取得成功: {ok_symbols}",
        f"- 取得失敗/欠損: {missing_symbols}",
        f"- 5分足行数: {total_rows:,}",
        f"- バックテスト判定数: {len(results):,}",
        f"- 厳格100%候補数: {len(candidates)}",
        f"- 判定: {'買わない' if candidates.empty else '過去100%候補あり（将来保証なし）'}",
        "",
        "※ 100%は過去の学習・独立検証区間での結果であり、将来の勝率100%を保証しません。",
        "※ 実売買はOFFです。"
    ]
    Path("outputs/RESULT_JP.md").write_text("\n".join(lines), encoding="utf-8")

    print("\n".join(lines))

if __name__ == "__main__":
    main()
