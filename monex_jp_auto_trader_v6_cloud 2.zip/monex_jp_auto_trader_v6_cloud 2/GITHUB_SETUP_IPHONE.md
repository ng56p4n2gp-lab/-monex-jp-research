# iPhoneで最短セットアップ

このプロジェクトはONE WORLDとは別のGitHubリポジトリに置いてください。

## 推奨名
`monex-jp-research`

## 公開設定
**Private（非公開）推奨**

理由:
- 投資ロジックを公開しない
- GitHub FreeでもPrivate Actionsに月2,000分の無料枠がある
- 初回は手動実行だけなので、勝手に毎日時間を消費しない

## リポジトリ作成後
ChatGPTのGitHub接続に新しい `monex-jp-research` を許可してください。
その後はChatGPT側からコードを入れられます。

## 実行
GitHub → monex-jp-research → Actions → Learn last 60 days → Run workflow

結果は Actions の `monex-60d-learning-results` に出ます。

## 安全仕様
- マネックスID/パスワード不要
- 証券口座へ接続しない
- 注文しない
- live_trading=false
- 有料APIキー不要
