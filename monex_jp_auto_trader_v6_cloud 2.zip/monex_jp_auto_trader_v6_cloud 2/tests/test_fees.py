from monex_trader.fees import monex_spot_fee, net_profit_after_costs
def test_fee_bands():
    assert monex_spot_fee(50000)==55
    assert monex_spot_fee(100000)==99
    assert monex_spot_fee(200000)==115
    assert monex_spot_fee(500000)==275
def test_profit_positive_example():
    assert net_profit_after_costs(2000,2017,100).net_profit > 1000
