import pandas as pd
from monex_trader.backtest import _session_id

def test_tse_sessions():
    assert _session_id(pd.Timestamp("2026-09-14 09:00"))=="2026-09-14-AM"
    assert _session_id(pd.Timestamp("2026-09-14 11:30"))=="2026-09-14-AM"
    assert _session_id(pd.Timestamp("2026-09-14 12:00")) is None
    assert _session_id(pd.Timestamp("2026-09-14 12:30"))=="2026-09-14-PM"
    assert _session_id(pd.Timestamp("2026-09-14 15:30"))=="2026-09-14-PM"
