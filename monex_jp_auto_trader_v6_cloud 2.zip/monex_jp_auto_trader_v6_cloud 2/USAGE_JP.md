# v4 無料版

## 自動ルート
1.
python -m monex_trader.cli universe --out data/master/tse_symbols.csv

2.
python -m monex_trader.cli download-free --symbols data/master/tse_symbols.csv --interval 5m --period 60d --out data/cache/history_5m.csv

3.
python -m monex_trader.cli backtest --bars data/cache/history_5m.csv --shares 100 --target 1000

## JPXページ仕様変更時の予備ルート
JPX公式サイトから「東証上場銘柄一覧」のExcelを保存して:

python -m monex_trader.cli universe --xlsx path/to/file.xlsx --out data/master/tse_symbols.csv

## 判定
strict100_candidates.csv が空なら売買候補なし。
過去の100%条件があっても将来100%を意味しません。
