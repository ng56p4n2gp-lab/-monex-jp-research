# Monex JP Auto Trader v6 CLOUD / FREE

直近60日・5分足を無料取得し、5分/10分以内に
マネックス手数料・税・スリッページを考慮して
ネット+1,000円へ到達したパターンを研究するシステムです。

## v6
- GitHub Actionsでネット接続環境から実行
- JPX公式上場銘柄一覧を自動取得
- Yahoo/yfinanceで60日5分足を段階取得
- 取得失敗銘柄を必ずレポート
- Parquet圧縮で一時データを保存
- 銘柄チャンクごとにバックテストしてメモリ節約
- 学習/検証を分けたウォークフォワード
- 全検証区間100%の条件だけ候補
- 候補ゼロならNO_TRADE
- 実売買OFF

## GitHub Actions
`.github/workflows/learn_60d.yml`

初回は `workflow_dispatch`（手動実行）のみです。
勝手に無料枠を消費しないため、定期実行はまだ有効化していません。

## 無料枠を守る設計
GitHub FreeのPrivate Actions無料枠内で運用する前提ですが、
実際の所要時間はYahoo側の応答や対象銘柄数で変わります。
timeoutは180分で強制停止します。

## 注意
- yfinanceは非公式データ取得ライブラリです。
- 全東証銘柄の完全取得は保証されません。欠損はdownload_report.csvへ出します。
- 過去100%は将来100%を意味しません。
- live tradingはロックされています。
